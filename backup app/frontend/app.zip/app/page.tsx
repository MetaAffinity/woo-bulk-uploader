import { redirect } from 'next/navigation'

export default function Home() {
  redirect('/bulk-upload')
}
